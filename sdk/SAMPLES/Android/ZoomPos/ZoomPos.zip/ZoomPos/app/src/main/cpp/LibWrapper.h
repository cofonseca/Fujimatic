//
// Created by P70352 on 2024/03/15.
//

#ifndef SDKWRAPPER_H
#define SDKWRAPPER_H

#endif //SDKWRAPPER_H

#include "XAPI.H"
#include "XAPI_MOV.H"
#include "XAPIOpt.H"
#include "XAPIOpt_MOV.H"

enum {
    XSDK_SUCCESS = 0,
    XSDK_APP_ERROR = -1,
    XSDK_NOT_FOUND_API = -2,
};

void Set_longTojlongFld(JNIEnv *pEnv, jobject obj, jclass clazz, const char *FieldName, long longbuf);
