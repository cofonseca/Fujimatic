package com.fujifilm.zoompos

object ZoomPosState {
    var isStartZoomFocal = false
    var connectState = false
    var errorCount = 0
}