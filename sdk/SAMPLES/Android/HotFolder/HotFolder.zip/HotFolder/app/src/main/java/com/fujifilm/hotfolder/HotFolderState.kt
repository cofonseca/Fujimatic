package com.fujifilm.hotfolder

object HotFolderState {
    var isStartReadImage = false
    var connectState = false
}