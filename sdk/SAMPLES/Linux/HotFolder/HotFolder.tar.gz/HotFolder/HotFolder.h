// HotFolder.h
#pragma once 

enum{
	STATE_DISCONNECT = 0,
	STATE_CONNECT    = 1,
	STATE_BUSY		 = 2,
};

#define FALSE 0
#define TRUE 1
typedef int BOOL;

void CheckFolder(std::string savePath, BOOL* pboErr);
void StopLoop(int signum);
