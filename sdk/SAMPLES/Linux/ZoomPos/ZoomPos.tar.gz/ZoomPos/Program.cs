﻿// See https://aka.ms/new-console-template for more information
using System;
using Gtk;

public class MyApp
{
    public static void Main()
    {
        Application.Init();
        ZoomPosForm window = new ZoomPosForm();
        window.ShowAll();
        Application.Run();
    }
}
