//
//  ToolConst.swift
//  MultipleCameraControl
//
//  Created by saito shota on 2024/10/04.
//

import Foundation

struct DetectedListInfo: Identifiable
{
    var id = UUID()
    var DeviceIndex: String
    var Valid: String
    var Product: String
    var SerialNoIP: String
}

struct ConnectedListInfo: Identifiable
{
    var id = UUID()
    var DeviceIndex: Int
    var Vendor: String
    var Product: String
    var Firmware: String
    var Sensitivity: String
    var hCamera: XSDK_HANDLE
}
