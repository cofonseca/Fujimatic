//
//  MultipleCameraControlApp.swift
//  MultipleCameraControl
//
//  Created by saito shota on 2024/10/04.
//

import SwiftUI

@main
struct MultipleCameraControlApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
