﻿namespace ZoomPos;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}

	protected override Window CreateWindow(IActivationState activationState)
    {
        Window window = base.CreateWindow(activationState);

        window.MinimumWidth = 500;
		window.MaximumWidth = 500;
		window.MinimumHeight = 400;
		window.MaximumHeight = 400;
        return window;
    }
}
