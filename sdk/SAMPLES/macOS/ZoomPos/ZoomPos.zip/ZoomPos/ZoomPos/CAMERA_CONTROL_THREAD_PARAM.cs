﻿using System;

namespace ZoomPos
{
    internal struct CAMERA_CONTROL_THREAD_PARAM
    {
        public IntPtr hCam;
        public string ptchModel;
        public string ptchSerial;
        public string ptchOriginalName;
        public int iVersion;

        public bool boCapabilityTether;
        public bool boCapabilityBackupRestore;

        public bool phEventExitConnect;
        public bool phEventExitPoll;

        public long lInterface;
        public string ptchInterface;

        public long lFocalLength;
        public long l35mmFocalLength;
        public int lBusyCount;
    }
}
